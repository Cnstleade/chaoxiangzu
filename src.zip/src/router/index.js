import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

Vue.use(Router)

export default new Router({
  routes: [{
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/home',
      component: resolve => require(['../components/page/home.vue'], resolve)
    },
    {
      path: '/admin',
      component: resolve => require(['../components/common/Home.vue'], resolve),
      meta: {
        title: '自述文件'
      },
      children: [{
        path: '/goods1',
        component: resolve => require(['../components/page/goods/goods1.vue'], resolve),
        meta: {
          title: '自述文件'
        },
      },{
        path: '/goods1',
        component: resolve => require(['../components/page/goods/goods1.vue'], resolve),
        meta: {
          title: '房源详情'
        },
      },{
        path: '/goods3',
        component: resolve => require(['../components/page/goods/goods3.vue'], resolve),
        meta: {
          title: '已租房源'
        },
      },{
        path: '/goods4',
        component: resolve => require(['../components/page/goods/goods4.vue'], resolve),
        meta: {
          title: '维护中房源'
        },
      },{
        path: '/goods5',
        component: resolve => require(['../components/page/goods/goods5.vue'], resolve),
        meta: {
          title: '待租房源'
        },
      },{
        path: '/order1',
        component: resolve => require(['../components/page/order/order1.vue'], resolve),
        meta: {
          title: '有效订单'
        },
      },{
        path: '/order2',
        component: resolve => require(['../components/page/order/order2.vue'], resolve),
        meta: {
          title: '订单中心'
        },
      }]
    }
  ]
})
