export const playMode = {
  sequence: 0,
  loop: 1,
  random: 2
}
